#include "potion.h"

Potion::Potion(int x, int y, ObjectType t, int val): Item{x,y, t, val} {}

Potion::~Potion(){}
