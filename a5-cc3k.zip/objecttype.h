#ifndef OBJECTTYPE_H
#define OBJECTTYPE_H
enum class ObjectType {RH,PH,BA,BD,WA,WD,horizontalwall, wall, blank, door, passage, emptytile, stairs,
Dragon, Dwarf, Elf, Human, Halfling, Merchant, Orcs, Shade, Vampire, Drow, Troll, Goblin, Gold};
#endif
