#include "blank.h"


using namespace std;
blank::blank(int x, int y, ObjectType type): Object(x,y,type){}//:x{x},y{y},objectType{type}{}

blank::~blank() {}
