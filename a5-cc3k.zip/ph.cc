#include "ph.h"

PH::PH(int x, int y): Potion{x,y,ObjectType::PH,-10} {}
