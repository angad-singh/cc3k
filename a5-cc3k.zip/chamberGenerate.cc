#include <vector>
/*
int main() {
    vector chamber1;
    vector chamber2;
    vector chamber3;
    vector chamber4;
    vector chamber5;

    for (int row = 0; row < 25; row++) {
        for (int col = 0; col < 79; col++) {
            if(row == 3 || row == 4)
            {
                if(col > 2 && col < 29)
                    //add to chamber 1
                else if(col > 38 && col < 62)
                    //add to chamber 2
            }
            else if(row == 5)
            {
                if(col > 2 && col < 29)
                    //add to chamber 1
                else if(col > 38 && col < 70)
                //add to chamber 2
            }
            else if(row == 6)
            {
                if(col > 2 && col < 29)
                    //add to chamber 1
                        else if(col > 38 && col < 73)
                //add to chamber 2
            }
            else if(row == 7 || row == 8 || row == 9)
            {
                if(col > 60 && col < 76)
                    //add to chamber 2
            }
            else if(row == 10 || row == 11 || row == 12)
            {
                if(col > 60 && col < 76)
                //add to chamber 2
                else if(col > 37 && col < 50 )
                    //add to chamber 3
            }
            else if(row == 15)
            {
                if(col > 3 && col < 25)
                    //add to chamber 4
            }
            else if(row == 16 || row == 17 || row == 18)
            {
                if(col > 3 && col < 25)
                //add to chamber 4
                else if(col > 64 && col < 76)
                    //add to chamber 5
            }
            else if(row == 19 || row == 20 || row == 21)
            {
                if(col > 3 && col < 25)
                //add to chamber 4
                else if(col > 36 && col < 76)
                    //add to chamber 5
            }
        }
    }
}
*/
