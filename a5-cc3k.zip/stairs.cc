#include "stairs.h"

stairs::stairs(int row, int col):Object{row, col, ObjectType::stairs} {}
