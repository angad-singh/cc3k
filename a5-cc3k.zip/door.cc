#include "door.h"


using namespace std;

door::door(int x, int y, ObjectType type): Object(x,y,type) {}//:x{x},y{y},type{"door"} {

door::~door() {}
