#include "rh.h"
RH::RH(int x, int y): Potion{x,y,ObjectType::RH,10}{};
