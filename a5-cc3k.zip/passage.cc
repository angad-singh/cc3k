#include "passage.h"

using namespace std;

passage::passage(int x, int y, ObjectType type): Object(x,y,type){}

passage::~passage(){}
