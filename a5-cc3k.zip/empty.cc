#include "empty.h"


using namespace std;
emptytile::emptytile(int x, int y, ObjectType type): Object(x,y,type){}//:x{x},y{y},objectType{type}{}

emptytile::~emptytile() {}
